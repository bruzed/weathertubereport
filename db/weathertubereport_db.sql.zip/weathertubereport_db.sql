-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 08, 2011 at 11:58 PM
-- Server version: 5.0.91
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bruzed_weathertube`
--

-- --------------------------------------------------------

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
CREATE TABLE IF NOT EXISTS `conditions` (
  `id` int(11) NOT NULL auto_increment,
  `condition_name` varchar(50) NOT NULL,
  `guitar` varchar(200) NOT NULL,
  `percussion` varchar(200) NOT NULL,
  `bass` varchar(200) NOT NULL,
  `wind` varchar(200) NOT NULL,
  `keyboard` varchar(200) NOT NULL,
  `style` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `conditions`
--

INSERT INTO `conditions` (`id`, `condition_name`, `guitar`, `percussion`, `bass`, `wind`, `keyboard`, `style`) VALUES
(1, 'tornado', 'electric/guitar', 'drums/-dub/-raggae', 'electric/bass/guitar/-strum/-acoustic/-imelda/-saxophone', 'saxophone/-guitar/-drums/-piano/-synthesizer/-keyboard/-bass/-world/-stubenhaus/-tabla/-orchestra/-percussion/-Lizards/-quartet/-band/-Film&amp;Animation/-trashcanschool', 'synthesizer/-programming/-Howto&amp;Style', 'noise'),
(3, 'snow', 'steel/electric/acoustic/guitar/-lava/-lavamusic/-percussion/-bongo/-conga/-crowd/-ancient', 'drums/-dub/-raggae', 'upright/bass/guitar/-singer/-heather/-miles/-siame/-theloniousdub/-viola/-fpe', 'trumpet/-percussion/-festival/-jam/-method/-bolvin', 'piano/-production/-movie/-hollywood/-saxaphone/-sax/-guitar/-bass/-satoru/-shinoya/-orchestra/-drums/-guitar/-tony/-grey', 'jazz'),
(28, 'clear', 'electric/guitar', 'drums/-dub/-raggae', 'electric/bass/guitar/-strum/-acoustic/-imelda', 'soprano/saxophone/-guitar/-drums/-piano/-synthesizer/-keyboard/-bass/-world/-stubenhaus/-tabla/-orchestra/-percussion/-Lizards/-quartet/-band/-Film&amp;Animation', 'synthesizer/-programming/-Howto&amp;Style', 'funk'),
(27, 'cloudy', 'acoustic/guitar/-shakti', 'percussion/-piano/-bass/-guitar/-sax/-saxophone/-band/-irakere/-steelband', 'electric/bass/guitar', 'saxophone/-guitar/-drums/-piano/-synthesizer/-keyboard/-bass/-world/-stubenhaus/-tabla/-orchestra/-percussion/-Lizards/-quartet/-band/-Film&amp;Animation/-kenny', 'piano/keyboard/synthesizer/-production/-movie/-hollywood/-saxaphone/-sax/-guitar/-bass/-satoru/-shinoya/-orchestra/-drums/-guitar/-tony/-grey', 'electronic'),
(26, 'windy', 'electric/guitar', 'drums/-dub/-raggae', 'electric/bass/guitar/-strum/-acoustic/-imelda', 'drum/drums/-dub/-reggae', 'synthesizer/-programming/-Howto&amp;Style', 'heavy/metal'),
(25, 'foggy', 'electric/guitar', 'drums/-dub/-raggae', 'electric/bass/guitar/-strum/-acoustic/-imelda', 'drum/drums/-dub/-reggae/-appice/-krupa', 'piano/-production/-movie/-hollywood/-saxaphone/-sax/-guitar/-bass/-satoru/-shinoya/-orchestra/-drums/-guitar/-tony/-grey/-ben/-folds', 'rock'),
(24, 'hail', 'electric/guitar', 'drums/-dub/-raggae', 'electric/bass/guitar/-strum/-acoustic/-imelda/-samandiam', 'drum/drums/-dub/-reggae', 'synthesizer/-programming/-Howto&amp;Style', 'progressive/rock'),
(23, 'rain', 'acoustic/guitar/-shakti', 'drums/-dub/-raggae', 'upright/bass/guitar/-singer/-heather/-miles/-siame/-theloniousdub/-viola', 'flute/-bass/-guitar/-drum/-drums/-piano/-tabla', 'piano/-production/-movie/-hollywood/-saxaphone/-sax/-guitar/-bass/-satoru/-shinoya/-orchestra/-drums/-guitar/-tony/-grey', 'ambient'),
(29, 'hot', 'electric/guitar', 'percussion/-piano/-bass/-guitar/-sax/-saxophone/-band/-irakere/-steelband', 'electric/bass/guitar/-strum/-acoustic/-imelda', 'harmonica', 'synthesizer/-programming/-Howto&amp;Style', 'blues');

-- --------------------------------------------------------

--
-- Table structure for table `instruments`
--

DROP TABLE IF EXISTS `instruments`;
CREATE TABLE IF NOT EXISTS `instruments` (
  `id` int(11) NOT NULL auto_increment,
  `instrument_type` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `instruments`
--

INSERT INTO `instruments` (`id`, `instrument_type`) VALUES
(2, 'guitar'),
(3, 'bass'),
(4, 'wind'),
(5, 'keyboard');

-- --------------------------------------------------------

--
-- Table structure for table `shared`
--

DROP TABLE IF EXISTS `shared`;
CREATE TABLE IF NOT EXISTS `shared` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `weathercondition` varchar(100) NOT NULL,
  `location` varchar(200) NOT NULL,
  `weatherimage` varchar(200) NOT NULL,
  `songname` text NOT NULL,
  `video0` varchar(200) NOT NULL,
  `video1` varchar(200) NOT NULL,
  `video2` varchar(200) NOT NULL,
  `video3` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=155 ;

--
-- Dumping data for table `shared`
--

INSERT INTO `shared` (`id`, `name`, `weathercondition`, `location`, `weatherimage`, `songname`, `video0`, `video1`, `video2`, `video3`) VALUES
(89, 'rubwteeeatrpaieamorrymeippiiueer', 'clear', 'Conditions for San Rafael, CA at 2:50 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            59Â°F, <strong>clear</strong> mysterious the crystal ', 'http://www.youtube.com/v/lfiE4hZbd7U?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/aX6WxALQeuM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/c8qRXBfU5FA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/BcvO-hFD5IY?f=videos&app=youtube_gdata'),
(90, 'aegzteguptrygaaribrrenzuriuoerbb', 'snow', 'Conditions for New York, NY at 5:59 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            34Â°F, <strong>snow</strong> ball fire umbrellas ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/QtHAui60N24?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Nrrwovi01bE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/TeDTizLWx44?f=videos&app=youtube_gdata'),
(91, 'zbrpoebpttrytpwoebzrrpewaeirthep', 'snow', 'Conditions for New York, NY at 5:59 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            34Â°F, <strong>snow</strong> traveller for ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/ZGF_-7t5uWg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/94IM3JeGqy8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/fNJSIAWMboE?f=videos&app=youtube_gdata'),
(92, 'ipinrrteguteaeoeigytrggtpaatgwpz', 'snow', 'Conditions for New York, NY at 5:59 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            34Â°F, <strong>snow</strong> waltz morning way ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/NqOKQ0H83WQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata'),
(93, 'utuetbypseirtttueiegierhatntwetu', 'snow', '', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            \n            34Â°F, <strong>snow</strong> waltz morning way ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/NqOKQ0H83WQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata'),
(94, 'eybtmztebaaptiroeeahrybzpttreaay', 'snow', '', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            \n            34Â°F, <strong>snow</strong> waltz morning way ', 'http://www.youtube.com/v/NqOKQ0H83WQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata'),
(95, 'aiahtuarmreaottbetgepahitweagauy', 'snow', '', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            \n            34Â°F, <strong>snow</strong> waltz morning way ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/NqOKQ0H83WQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata'),
(96, 'zesewtwmrntuprbsianrnpameitztptg', 'snow', '', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            \n            34Â°F, <strong>snow</strong> waltz morning way ', 'http://www.youtube.com/v/NqOKQ0H83WQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata'),
(97, 'agewharteeawmrihnwtuairtttwhetnr', 'cloudy', 'Conditions for Zoelmond, NL at 4:00 am CET', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            46Â°F, <strong>cloudy</strong> it is sound ', 'http://www.youtube.com/v/YxEO6iAbzgc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/0j4TqJXg2Vs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/d3CJdm5pVc8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/eJctPre3WxE?f=videos&app=youtube_gdata'),
(98, 'rhebihmttaamtaesrneawtaerhemsama', 'snow', 'Conditions for New York, NY at 12:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/16d.png', '\n            27Â°F, <strong>snow</strong> crystal sound ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/vx_1IPGyyYU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/vhKkYyVyhcc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/zNr5KLiGxq8?f=videos&app=youtube_gdata'),
(99, 'heatrpnrrnshseeuepegaeteeauuaasw', 'snow', 'Conditions for New York, NY at 12:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/16d.png', '\n            27Â°F, <strong>snow</strong> blue street it ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/kRk2fVKjMMA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/M4xy-wxc1Y0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/l9N6_GcWGF4?f=videos&app=youtube_gdata'),
(100, 'payzeeuarehuratreaazbipetttoatrh', 'cloudy', 'Conditions for San Francisco, CA at 8:56 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/29d.png', '\n            55Â°F, <strong>cloudy</strong> soldier August directions ', 'http://www.youtube.com/v/6AGO6ehNis8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/oeAJauayxJQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/V-FvoRbp6xo?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/e5-eWFcUKn8?f=videos&app=youtube_gdata'),
(101, 'tithrwoenrroggpaerwteoueipthehrt', 'clear', 'Conditions for Seattle, WA at 8:53 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '51Â°F, <STRONG>clear</STRONG> soldier two juggler ', 'http://www.youtube.com/v/d7tgIxzNBMM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/OqS01wpctko?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/a3drowMha9I?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/V94DEkafczs?f=videos&app=youtube_gdata'),
(102, 'twtmaeargattezthprsphoprintetera', 'light snow/fog', 'Conditions for New York, NY at 11:51 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            29Â°F, <strong>light snow/fog</strong> crystal when adios 29Â°F, <strong>light snow/fog</strong> way with made ', '', '', '', ''),
(103, 'eirypaoeahpetrregaaggtttgpeyosbg', 'snow', 'Conditions for New York, NY at 12:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/16d.png', '\n            27Â°F, <strong>snow</strong> arrow vertical slang ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/zNr5KLiGxq8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/IbBILj5jzTE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9QRl4cYmw_Y?f=videos&app=youtube_gdata'),
(104, 'mithrhepeieeneatgsrzytrrtaitntia', 'clear', 'Conditions for Palo Alto, CA at 9:56 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            56Â°F, <strong>clear</strong> sunday lady lines ', 'http://www.youtube.com/v/w7J_qp-iH9Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/OjL-abDTDlU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/V7d36r0gZJE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/s1syrV0bQPM?f=videos&app=youtube_gdata'),
(105, 'esaenegrrataieaemmetatibhayzrryu', 'clear', 'Conditions for Beverly Hills, CA at 9:51 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            57Â°F, <strong>clear</strong> rose milky for ', 'http://www.youtube.com/v/28qgeEsBri8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/V7d36r0gZJE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/aX6WxALQeuM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/gQEO55-_tdw?f=videos&app=youtube_gdata'),
(106, 'rpttetiiboeypobatpsraoatberigete', 'clear', 'Conditions for Porter Ranch, CA at 9:51 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            58Â°F, <strong>clear</strong> sundance unknown adios ', 'http://www.youtube.com/v/AGa8FsE25sY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/_6jovFSivbU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/s-haXu-Uoog?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/ieHC5EBitnE?f=videos&app=youtube_gdata'),
(107, 'iayruttzhiurshhaeeeepitrziiereee', 'foggy', 'Conditions for MinatitlÃ¡n, MX at 12:00 am CST', 'http://l.yimg.com/a/i/us/nws/weather/gr/21d.png', '67Â°F, <STRONG>foggy</STRONG> orange for for ', 'http://www.youtube.com/v/WvDedo8r1Fk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/U1WUggukDjo?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/SVJTQVIaeu8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Qe6VIH-lQN4?f=videos&app=youtube_gdata'),
(108, 'rtazmgarpirtmnternasprrerruagrap', 'snow', 'Conditions for New York, NY at 2:05 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/16d.png', '\n            27Â°F, <strong>snow</strong> cannon for milky ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/uJYpRul4EUg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/LRCtegzM_Vw?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Zmfhe7BO0Wo?f=videos&app=youtube_gdata'),
(109, 'azwatueiunuyuazeatpiabrtmttptwps', 'cloudy', 'Conditions for Amersfoort, NL at 7:00 am CET', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            47Â°F, <strong>cloudy</strong> memory seventh ', 'http://www.youtube.com/v/fbjYxZMCjX0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/461TZMZrL6A?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/753SJHh5SSU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/qQNfsiDF500?f=videos&app=youtube_gdata'),
(110, 'trragrgmuteetsygrrrsyntotttiptat', 'clear', 'Conditions for Buckner, KY at 2:53 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            27Â°F, <strong>clear</strong> it juggler juggler ', 'http://www.youtube.com/v/lfiE4hZbd7U?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/pscWyIsuUy4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/JeSleOeNc6w?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/kkilZOrYA6s?f=videos&app=youtube_gdata'),
(111, 'earysiataegagametbinptetaeetthoi', 'snow', 'Conditions for Pittsburgh, PA at 4:29 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            21Â°F, <strong>snow</strong> tango juggler directions ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/I6Xod0AUig8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Tqu5imWbRlA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Ua07h5rTEqw?f=videos&app=youtube_gdata'),
(112, 'hzttwweebyritehbrmnrbretgootzege', 'clear', 'Conditions for Cupertino, CA at 12:56 am PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            53Â°F, <strong>clear</strong> moors for feathered ', 'http://www.youtube.com/v/QEGPjLbBC8M?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/74cQzz5GzJs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/hEXgiL9Uaj8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/uRyxFKP2dNE?f=videos&app=youtube_gdata'),
(113, 'seurtrpteaarhtermwbsmphetpspeemm', 'cloudy', 'Conditions for Virginia Beach, VA at 7:56 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '\n            34Â°F, <strong>cloudy</strong> for two umbrellas ', 'http://www.youtube.com/v/753SJHh5SSU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/yWm-DEet3OA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/98l33fQtumE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/kn7LgrKDJQI?f=videos&app=youtube_gdata'),
(114, 'seseytarmmeohbhetstnehzenhzieptt', 'fog', 'Conditions for Coatepec, MX at 6:40 am CST', 'http://l.yimg.com/a/i/us/nws/weather/gr/20d.png', '\n            52Â°F, <strong>fog</strong> feathered now slang ', '', '', '', ''),
(115, 'aeioareoiimpiearmeiineeaezueieog', 'snow', 'Conditions for New York, NY at 9:42 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            28Â°F, <strong>snow</strong> mysterious juggler ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/oq3sk6w1n9c?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/VQ-EK4Hn_XE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HPiZoND209U?f=videos&app=youtube_gdata'),
(116, 'ihhwaturpeaprptgyreerhatmpytentp', 'clear', 'Conditions for Gainesville, FL at 10:53 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            50Â°F, <strong>clear</strong> American non-stop ', 'http://www.youtube.com/v/kgPT71aPBOw?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/jI8E89zpq20?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/BJoxYE6lylc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/4dM8lfQgaBU?f=videos&app=youtube_gdata'),
(117, 'eaearaaarrrpeosgtgtabeeewmbntaoi', 'snow', 'Conditions for New York, NY at 11:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/14d.png', '\n            30Â°F, <strong>snow</strong> second blackthorn rose ', 'http://www.youtube.com/v/f9GL7EYdaNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Tqu5imWbRlA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/oq3sk6w1n9c?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/rEUWr3T_Ag0?f=videos&app=youtube_gdata'),
(118, 'wrpptztpetaabzeasgungeiuyuerptep', 'cloudy', 'Conditions for Sunnyvale, CA at 6:56 pm PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/29d.png', '\n            56Â°F, <strong>cloudy</strong> is blue ', 'http://www.youtube.com/v/mbs9DrPJkkA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/R6ewqqq95ng?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/0y9L6Eve0ug?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/fbjYxZMCjX0?f=videos&app=youtube_gdata'),
(119, 'eeubperytaabutrpgireriyipabierbm', 'cloudy', 'Conditions for New York, NY at 8:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            30Â°F, <strong>cloudy</strong> medley in ', 'http://www.youtube.com/v/O3CpMDY72Tw?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/rK4WBeNl75g?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/6Scw6JChsQ8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/d3CJdm5pVc8?f=videos&app=youtube_gdata'),
(120, 'rrwertretnoittiuiehragatyureeaez', 'cloudy', 'Conditions for New York, NY at 1:27 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            36Â°F, <strong>cloudy</strong> waltz market slumber ', 'http://www.youtube.com/v/Tapa-MnfERE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/S-tQP4Bweq0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/_sviE9U8No4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/PLLhuyoaLtQ?f=videos&app=youtube_gdata'),
(121, 'ytaptbnrttirrreetepwoirgbtariont', 'cloudy', 'Conditions for New York, NY at 1:27 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            36Â°F, <strong>cloudy</strong> crystal made way ', 'http://www.youtube.com/v/0j4TqJXg2Vs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/msuQrxE0fdM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/S-tQP4Bweq0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/gqknVLw-YLA?f=videos&app=youtube_gdata'),
(122, 'rrrtaorrtttzwirbettaryeretetrarp', 'cloudy', 'Conditions for New York, NY at 1:27 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            36Â°F, <strong>cloudy</strong> unknown blue rockin'' ', 'http://www.youtube.com/v/lOfTYOYDj2g?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/EUSQBBtplqk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/_RTGzrabtEI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/ND2HHk8mbJ4?f=videos&app=youtube_gdata'),
(123, 'izaeetepmamypepgtiehespmtuatzega', 'cloudy', 'Conditions for Pound Ridge, NY at 12:53 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            34Â°F, <strong>cloudy</strong> lady rose ', 'http://www.youtube.com/v/KKUo_PveNMg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/EShoJU9Ghcw?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/p_7ChH2YpbA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Rxe4u47BuVY?f=videos&app=youtube_gdata'),
(124, 'smbbauaepztbsgztreerwsrzrtheparz', 'cloudy', 'Conditions for Pound Ridge, NY at 12:53 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            34Â°F, <strong>cloudy</strong> two non-stop street ', 'http://www.youtube.com/v/0j4TqJXg2Vs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/wxY5C6HRwNs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/PgQxAZ0MB44?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/kFAiPfAOte8?f=videos&app=youtube_gdata'),
(125, 'eeberetrrzswmaotranseytpterttteg', 'cloudy', 'Conditions for Hilo, HI at 9:53 am HST', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '\n            77Â°F, <strong>cloudy</strong> orange crystal freezing ', 'http://www.youtube.com/v/0DmE1oZb1As?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/M6YBe8xP-RQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/fbjYxZMCjX0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Dc_kyt7ox7Q?f=videos&app=youtube_gdata'),
(126, 'tzriopuetrhtrpirepeetotrantipuee', 'cloudy', 'Conditions for New York, NY at 6:51 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            38Â°F, <strong>cloudy</strong> ball is ', 'http://www.youtube.com/v/KKUo_PveNMg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/f6yp0wXevAI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/maAoEW_FyZ0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/S0DDKwjPY5o?f=videos&app=youtube_gdata'),
(127, 'phhymspeaybosytpmernteraiabruaaa', 'clear', 'Conditions for New York, NY at 2:51 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            47Â°F, <strong>clear</strong> man moors milky ', 'http://www.youtube.com/v/AGa8FsE25sY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/xfydgQFMob8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/FlnZ05SGvlk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/yUQc4m-2MUI?f=videos&app=youtube_gdata'),
(128, 'mgiaotweorzeiustahooaeupaaenrinr', 'cloudy', 'Conditions for San Francisco, CA at 6:56 am PST', 'http://l.yimg.com/a/i/us/nws/weather/gr/28d.png', '\n            45Â°F, <strong>cloudy</strong> people adios in ', 'http://www.youtube.com/v/hH77HVEK2Mo?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/sFmH4jiMy9A?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/W9eWs6zDikY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/MLna2xSN2BI?f=videos&app=youtube_gdata'),
(129, 'pbrmpprupzeenttytaeuerozorereeya', 'clear', 'Conditions for New York, NY at 11:51 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            57Â°F, <strong>clear</strong> in cucumber blue ', 'http://www.youtube.com/v/w7J_qp-iH9Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/LfH9Jl3RQkI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/IW_54tpI5vE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/iEc8AuDYknw?f=videos&app=youtube_gdata'),
(130, 'rrebhteomzteheattzaprporatpbeate', 'rain', 'Conditions for New York, NY at 2:18 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/11d.png', '\n            52Â°F, <strong>rain</strong> August rockin'' ', 'http://www.youtube.com/v/ATC4r3zukmM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/QsxYNeLnvrQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/jDeiFU1aeyM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/JxVp7dr7_tg?f=videos&app=youtube_gdata'),
(131, 'styaaebtpiizreuettaatoeetruitmse', 'cloudy', 'Conditions for New York, NY at 10:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '\n            65Â°F, <strong>cloudy</strong> tears sundance for ', 'http://www.youtube.com/v/bRySi6FSjQ8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/l7abqToGLqE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/KKIO1qED4KI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/mbs9DrPJkkA?f=videos&app=youtube_gdata'),
(132, 'reaayeitipstmtattzegzreegtpeaaee', 'clear', 'Conditions for New York, NY at 10:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            57Â°F, <strong>clear</strong> in freezing ', 'http://www.youtube.com/v/kgPT71aPBOw?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/ICFp7oLhJAs?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/f37MzkVrfmA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/a3drowMha9I?f=videos&app=youtube_gdata'),
(133, 'typheyoapisrtstpibtsgitauutizaaw', 'cloudy', 'Conditions for San Carlos, CA at 2:47 pm PDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/28d.png', '\n            54Â°F, <strong>cloudy</strong> in freezing cucumber ', 'http://www.youtube.com/v/M6D4qpY_65M?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/rwX5tkSEy3k?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/LMnWp045qDE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/PLLhuyoaLtQ?f=videos&app=youtube_gdata'),
(134, 'agttawzetrhgyytrupatbtemezmeneaa', 'clear', 'Conditions for New York, NY at 5:51 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            66Â°F, <strong>clear</strong> now slumber with ', 'http://www.youtube.com/v/w7J_qp-iH9Y?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/hGed5_PVNrE?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/LOhrmVhx0nk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/V7d36r0gZJE?f=videos&app=youtube_gdata'),
(135, 'triaasapbytypotptrettmrewetyegtt', 'clear', 'Conditions for New York, NY at 1:51 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            76Â°F, <strong>clear</strong> morning woogie lady ', 'http://www.youtube.com/v/Au5j2-L9204?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/OqS01wpctko?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/FlnZ05SGvlk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/iEc8AuDYknw?f=videos&app=youtube_gdata'),
(136, 'wthzszttnttawistrmostopyguetzemi', 'clear', 'Conditions for Madison, CT at 9:35 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/33d.png', '\n            54Â°F, <strong>clear</strong> directions slang ', 'http://www.youtube.com/v/QEGPjLbBC8M?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/fIlShvQ7zx8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/pscWyIsuUy4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/f37MzkVrfmA?f=videos&app=youtube_gdata'),
(137, 'pgrirzesbtrtrwteepyaizbtgaeipsti', 'cloudy', 'Conditions for Rochester Mills, PA at 2:40 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/29d.png', '66Â°F, <STRONG>cloudy</STRONG> sunday made ', 'http://www.youtube.com/v/rnEuOfThHd8?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/mkioZOwwDVk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Dc_kyt7ox7Q?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/A7ojcnIOC8I?f=videos&app=youtube_gdata'),
(138, 'prrtoubreweetptstapwpahwzebpritr', 'cloudy', 'Conditions for New York, NY at 9:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            80Â°F, <strong>cloudy</strong> rockin'' orange thanks ', 'http://www.youtube.com/v/W9eWs6zDikY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/pjmIUZvKxP4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Z4nVNgM26e4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/8kxKpILT66A?f=videos&app=youtube_gdata'),
(139, 'bttrtyiaebmroeusauepwpraeiiyieae', 'cloudy', 'Conditions for New York, NY at 9:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            80Â°F, <strong>cloudy</strong> sound crystal 80Â°F, <strong>cloudy</strong> directions way with ', 'http://www.youtube.com/v/kM2ggTeAktA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/HacAWs5PMXg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/msuQrxE0fdM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/gthNrA05ZNY?f=videos&app=youtube_gdata'),
(140, 'aeoteotwreyaynerbmigiaeaiuaetane', 'clear', 'Conditions for Redwood City, CA at 3:47 pm PDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/32d.png', '\n            73Â°F, <strong>clear</strong> non-stop now ', 'http://www.youtube.com/v/d7tgIxzNBMM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/r-JtDfvcYCc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/LfH9Jl3RQkI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/iEc8AuDYknw?f=videos&app=youtube_gdata'),
(141, 'aammnbeeneerohhetpaaapoyengyaiut', 'cloudy', 'Conditions for Pocono Manor, PA at 1:53 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '\n            80Â°F, <strong>cloudy</strong> river made ', 'http://www.youtube.com/v/753SJHh5SSU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/_sviE9U8No4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/bVPqGXA47Vc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/KupOhDuwX7Q?f=videos&app=youtube_gdata'),
(142, 'pyhueeieptgygpsrptetpyyeriemwmzp', 'clear', 'Conditions for Parkton, NC at 1:53 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            86Â°F, <strong>clear</strong> traveller invader ', 'http://www.youtube.com/v/l3IuL4bJh9o?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/FhEzhody6eQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/taPFdtUewZA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/9EVZkZStQXQ?f=videos&app=youtube_gdata'),
(143, 'azntyuyroaemtieeimstatatbeioonbr', 'cloudy', 'Conditions for Mexico City, MX at 7:00 am CDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/27d.png', '\n            57Â°F, <strong>cloudy</strong> it sound ', 'http://www.youtube.com/v/yM2PtAiRVNk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Rxe4u47BuVY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/GUiRj6EWUCo?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/7elWm_DswvU?f=videos&app=youtube_gdata'),
(144, 'tagoaihouwtpetameeeatzgtmenaeeae', 'clear', 'Conditions for New York, NY at 1:51 pm EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            70Â°F, <strong>clear</strong> home river ', 'http://www.youtube.com/v/Gw1hAx5BvcI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/FhEzhody6eQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/BJoxYE6lylc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/xfydgQFMob8?f=videos&app=youtube_gdata'),
(145, 'etriyyuebtaprawieaeeprresotbgahh', 'clear', 'Conditions for Jersey City, NJ at 6:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            55Â°F, <strong>clear</strong> August hat ', 'http://www.youtube.com/v/l3IuL4bJh9o?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/BJoxYE6lylc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/7iHb9gagMxg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/pMoty8a9-Ks?f=videos&app=youtube_gdata'),
(146, 'yarimaygiwuttreztzeeayuhtbppprha', 'clear', 'Conditions for New York, NY at 7:51 am EDT', 'http://l.yimg.com/a/i/us/nws/weather/gr/34d.png', '\n            57Â°F, <strong>clear</strong> non-stop adios market ', 'http://www.youtube.com/v/An9_LG3Mc08?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/KUitiBYsOCM?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/IN4Ejv78kvg?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/xfydgQFMob8?f=videos&app=youtube_gdata'),
(147, 'rriieoyirzrrazieertagtrbmnpsrtps', 'cloudy', 'Conditions for New York, NY at 7:50 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/28d.png', '\n            22Â°F, <strong>cloudy</strong> milky cannon ', 'http://www.youtube.com/v/IyGkxFyIX3Q?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/PnMki50SC_0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/es76E8-wQqY?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/1RCHZbEDEgo?f=videos&app=youtube_gdata'),
(148, 'sugreprrahrtwpgnusryreiipeeztiuo', 'thunderstorm', 'Conditions for Rogers, AR at 6:35 am CST', 'http://l.yimg.com/a/i/us/nws/weather/gr/4d.png', '\n            63Â°F, <strong>thunderstorm</strong> lake orange slang ', '', '', '', ''),
(149, 'parigoaaauiheaohrroeeyprpatrreee', 'cloudy', 'Conditions for Schenectady, NY at 10:49 am EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '\n            19Â°F, <strong>cloudy</strong> second street waltz 19Â°F, <strong>cloudy</strong> street cucumber morning ', 'http://www.youtube.com/v/GUiRj6EWUCo?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/oeAJauayxJQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/u3tNKTpsFnI?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/S-tQP4Bweq0?f=videos&app=youtube_gdata'),
(150, 'iahteratagrrtrgaertayapateaiieru', 'cloudy', 'Conditions for Arvada, CO at 9:51 am MST', 'http://l.yimg.com/a/i/us/nws/weather/gr/28d.png', '\n            21Â°F, <strong>cloudy</strong> morning man American ', 'http://www.youtube.com/v/TYtNqt6MIis?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/1BDSUOTLf8E?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/oeAJauayxJQ?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/neMAKFVA9ss?f=videos&app=youtube_gdata'),
(151, 'upnrnapbrpbrhigrgeweowsahezirzoa', 'snow', 'Conditions for Detroit, MI at 7:53 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/16d.png', '\n            28Â°F, <strong>snow</strong> waterfall was invader ', 'http://www.youtube.com/v/UJq5aK6YiME?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Ns1ES5N-tJ0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Hz2rADrPUrc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/zNr5KLiGxq8?f=videos&app=youtube_gdata'),
(152, 'rsrrutngwertptutemeritteerprerrr', 'cloudy', 'Conditions for New York, NY at 10:50 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            25Â°F, <strong>cloudy</strong> is feathered with ', 'http://www.youtube.com/v/PEhqp8CP_Hc?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/pjmIUZvKxP4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/e9ZttCunw_Q?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/I3q5kQjMAbc?f=videos&app=youtube_gdata'),
(153, 'tareyptntrraptmpuaeotzrbterreare', 'cloudy', 'Conditions for Chanhassen, MN at 11:53 am CST', 'http://l.yimg.com/a/i/us/nws/weather/gr/30d.png', '6Â°F, <STRONG>cloudy</STRONG> soldier memory orange ', 'http://www.youtube.com/v/7zk7Nrr2KEA?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/F9IEa49ltm4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/Z4nVNgM26e4?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/maAoEW_FyZ0?f=videos&app=youtube_gdata'),
(154, 'eroperyhnrzatoireuezetahupenaapi', 'cloudy', 'Conditions for New York, NY at 11:50 pm EST', 'http://l.yimg.com/a/i/us/nws/weather/gr/26d.png', '\n            51Â°F, <strong>cloudy</strong> way invader with ', 'http://www.youtube.com/v/PFZ2i9HdlCk?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/S-tQP4Bweq0?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/kKvWGg4kkpU?f=videos&app=youtube_gdata', 'http://www.youtube.com/v/_sviE9U8No4?f=videos&app=youtube_gdata');

-- --------------------------------------------------------

--
-- Table structure for table `songwords`
--

DROP TABLE IF EXISTS `songwords`;
CREATE TABLE IF NOT EXISTS `songwords` (
  `id` int(50) NOT NULL auto_increment,
  `word` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `songwords`
--

INSERT INTO `songwords` (`id`, `word`) VALUES
(1, 'milky'),
(2, 'way'),
(3, 'umbrellas'),
(4, 'seventh'),
(5, 'arrow'),
(6, 'orange'),
(7, 'lady'),
(8, 'morning'),
(9, 'lake'),
(10, 'waterfall'),
(11, 'tears'),
(12, 'unknown'),
(13, 'soldier'),
(15, 'moors'),
(16, 'crystal'),
(17, 'crystal'),
(18, 'second'),
(19, 'sunday'),
(20, 'in'),
(21, 'August'),
(22, 'medley'),
(23, 'vertical'),
(24, 'invader'),
(25, 'directions'),
(26, 'boogie'),
(27, 'woogie'),
(28, 'waltz'),
(29, 'adios'),
(30, 'street'),
(31, 'home'),
(32, 'non-stop'),
(33, 'sundance'),
(34, 'American'),
(35, 'tango'),
(36, 'cucumber'),
(37, 'slumber'),
(38, 'mysterious'),
(39, 'traveller'),
(40, 'blackthorn'),
(41, 'rose'),
(42, 'freezing'),
(43, 'fire'),
(44, 'cannon'),
(45, 'ball'),
(46, 'market'),
(47, 'feathered'),
(48, 'hat'),
(49, 'juggler'),
(51, 'river'),
(52, 'people'),
(53, 'slang'),
(54, 'thanks'),
(55, 'for'),
(56, 'memory'),
(57, 'made'),
(58, 'rockin'''),
(59, 'when'),
(60, 'it'),
(61, 'was'),
(62, 'now'),
(63, 'blue'),
(64, 'sound'),
(65, 'this'),
(66, 'is'),
(67, 'man'),
(68, 'with'),
(69, 'update'),
(70, 'swamp'),
(71, 'two'),
(72, 'lines'),
(73, 'is'),
(75, 'speechless'),
(76, 'hire'),
(77, 'for'),
(78, 'with'),
(79, 'is'),
(80, 'it');
